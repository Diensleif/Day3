﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helper
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var entities = new Entities();

            var source = File.ReadAllText("Source.txt");

            var rows = source.Split('\n');
            for (var i = 0; i < rows.Length; i++)
            {
                var row = rows[i];
                row = row.Replace("\r", "");
                row = row.Replace("[", "");
                row = row.Replace("]", "");
                row = row.Replace("{", "");
                row = row.Replace("}", "");
                row = row.Replace("\"code\"", "");
                row = row.Replace(":", "");

                var cols = row.Split('\t');
                var userId = Convert.ToInt32(cols[0]);

                var services = cols[1].Split(',');
                foreach (var service in services)
                {
                    var userService = new UserService();

                    var id = 1;
                    if (entities.UserService.Count() != 0)
                    {
                        id = entities.UserService.Max(x => x.Id) + 1;
                    }

                    userService.Id = id;
                    userService.UserId = userId;
                    userService.ServiceId = Convert.ToInt32(service);

                    entities.UserService.Add(userService);
                    entities.SaveChanges();
                }
            }
        }
    }
}
